extends SceneTree
## Команда: godot --headless --path . --script res://tests/smoke_test.gd


func _initialize() -> void:
    call_deferred("_run_smoke_test")


func _run_smoke_test() -> void:
    var packed: PackedScene = load("res://scenes/main.tscn")
    if packed == null:
        push_error("Main scene was not loaded")
        quit(1)
        return
    var main: CorridorGame = packed.instantiate() as CorridorGame
    root.add_child(main)
    await process_frame
    if not is_instance_valid(main.get_node_or_null("World")):
        push_error("World node is missing")
        quit(1)
        return
    if not is_instance_valid(main.get_node_or_null("Player")):
        push_error("Player node is missing")
        quit(1)
        return
    if not is_instance_valid(main.get_node_or_null("HUD/Overlay")):
        push_error("UI overlay is missing")
        quit(1)
        return
    if main.phase != "dialogue":
        push_error("Opening dialogue was not shown")
        quit(1)
        return
    # Проверяем причинную цепочку спокойной концовки напрямую.
    main._close_dialogue()
    main._say(["testing"], ["trust", "lie"], "nika")
    main._choose(0)
    if not main.nika_trust:
        push_error("Trust option did not work")
        quit(1)
        return
    main._close_dialogue()
    main.player.position = Vector2(291, 191)
    main._interact()
    if not main.has_badge:
        push_error("Badge was not collected")
        quit(1)
        return
    main._close_dialogue()
    main.player.position = Vector2(351, 70)
    main._interact()
    if not main.door_unlocked:
        push_error("Scanner did not unlock")
        quit(1)
        return
    main._close_dialogue()
    main.door_unlocked = false
    main.world.door_unlocked = false
    main._start_alarm()
    main.alarm_cursor = Vector2(640, 270)
    main._update_alarm(9.1)
    if not main.door_unlocked:
        push_error("Alarm completion did not unlock the exit")
        quit(1)
        return
    print("SMOKE_TEST_PASSED")
    quit(0)
