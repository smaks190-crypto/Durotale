"""Lightweight static checks; actual engine and rendering require Godot CLI."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
project = (root / "project.godot").read_text(encoding="utf-8")
scene = (root / "scenes/main.tscn").read_text(encoding="utf-8")
assert '[application]' in project
assert 'run/main_scene="res://scenes/main.tscn"' in project
resources = re.findall(r'path="(res://[^"]+)"', scene)
assert len(resources) == 5, resources
for uri in resources:
    assert (root / uri.removeprefix('res://')).exists(), uri
for name in ['Main', 'World', 'Player', 'HUD', 'Overlay', 'TouchControls']:
    assert f'node name="{name}"' in scene, name
scripts = {p.name: p.read_text(encoding="utf-8") for p in (root / "scripts").glob("*.gd")}
assert len(scripts) == 5
assert 'extends CharacterBody2D' in scripts['player.gd']
assert 'move_and_slide()' in scripts['player.gd']
assert 'CollisionShape2D.new()' in scripts['world.gd']
assert 'dialogue_action' in scripts['main.gd']
assert '_update_alarm' in scripts['main.gd']
assert '_draw_dialogue' in scripts['overlay.gd']
assert 'VISIBILITY_TOUCHSCREEN_ONLY' in scripts['mobile_controls.gd']
assert 'Input.is_action_just_pressed("mobile_action")' in scripts['main.gd']
assert (root / 'export_presets.cfg').is_file()
assert (root / '.github/workflows/build-android.yml').is_file()
assert len(list((root/'assets/touch').glob('*.svg'))) == 8
for name, src in scripts.items():
    assert not re.search(r'^const\s+\w+\s+:=', src, re.M), name
    assert src.count('(') >= src.count(')') - 20, name  # loose sanity only
print('STATIC_CHECKS_PASSED: 5 scripts, touch controls, export preset, workflow, gameplay hooks')
