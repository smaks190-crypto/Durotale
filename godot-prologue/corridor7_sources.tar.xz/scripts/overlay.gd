extends Control
class_name GameOverlay
## Рисуем интерфейс на CanvasLayer поверх масштабированной карты.

const WHITE = Color("e8e5d9")
const MUTED = Color("99a9b5")
const ACCENT = Color("b7dfce")
const PANEL = Color("101824")
const BORDER = Color("7896a7")

var state: Dictionary = {}


func set_state(new_state: Dictionary) -> void:
    state = new_state
    queue_redraw()


func _font() -> Font:
    return ThemeDB.fallback_font


func _line(text: String, x: float, y: float, size: int = 20, color: Color = WHITE) -> void:
    draw_string(_font(), Vector2(x, y), text, HORIZONTAL_ALIGNMENT_LEFT, -1.0, size, color)


func _draw() -> void:
    if state.is_empty():
        return
    var phase: String = state.get("phase", "explore")
    # Минимальный HUD, видимый во время исследования.
    draw_rect(Rect2(17, 17, 382, 58), Color("101824"))
    draw_rect(Rect2(17, 17, 382, 3), BORDER)
    _line("КОРИДОР №7   /   03:17", 30, 44, 22)
    var badge_label := "ПРОПУСК: ЕСТЬ" if state.get("badge", false) else "ПРОПУСК: НЕТ"
    _line(badge_label, 30, 67, 17, ACCENT if state.get("badge", false) else MUTED)
    if phase == "explore":
        draw_rect(Rect2(20, 479, 920, 43), PANEL)
        _line(str(state.get("hint", "")), 35, 509, 21, ACCENT)
    elif phase == "dialogue":
        _draw_dialogue()
    elif phase == "alarm":
        _draw_alarm()
    elif phase == "ending":
        _draw_ending()


func _draw_dialogue() -> void:
    draw_rect(Rect2(31, 324, 898, 193), PANEL)
    draw_rect(Rect2(31, 324, 898, 3), BORDER)
    draw_rect(Rect2(31, 514, 898, 3), BORDER)
    var lines: Array = state.get("lines", [])
    for i in range(mini(lines.size(), 4)):
        _line(str(lines[i]), 51, 358 + i * 29, 21)
    var options: Array = state.get("options", [])
    if options.is_empty():
        _line("● — ДАЛЬШЕ" if OS.has_feature("mobile") else "E / ENTER — ДАЛЬШЕ", 652, 500, 17, ACCENT)
    else:
        for i in range(mini(options.size(), 2)):
            _line(str(options[i]), 52, 467 + i * 27, 18, ACCENT)


func _draw_alarm() -> void:
    draw_rect(Rect2(260, 115, 440, 302), PANEL)
    draw_rect(Rect2(260, 115, 440, 3), Color("e07d88"))
    _line("ПРОВЕРКА ДВИЖЕНИЯ", 283, 150, 22)
    draw_rect(Rect2(294, 160, 372, 218), Color("1c2a3a"))
    draw_rect(Rect2(305, 171, 350, 198), BORDER, false, 3.0)
    var scan_x: float = state.get("pulse_x", 480.0)
    draw_rect(Rect2(scan_x - 7.0, 173, 14, 194), Color(0.9, 0.2, 0.29, 0.45))
    draw_rect(Rect2(scan_x - 2.0, 173, 4, 194), Color("ff6c76"))
    var cursor: Vector2 = state.get("cursor", Vector2(480, 270))
    draw_rect(Rect2(cursor.x - 7.0, cursor.y - 7.0, 14, 14), WHITE)
    draw_rect(Rect2(cursor.x - 3.0, cursor.y - 3.0, 6, 6), Color("364455"))
    _line("ЗАЩИТА: %d/3" % int(state.get("health", 3)), 283, 402, 17)
    _line("%.1f / 9.0 C" % float(state.get("time", 0.0)), 547, 402, 17)
    draw_rect(Rect2(180, 455, 600, 62), PANEL)
    var instruction: String = "КРЕСТОВИНА — УХОДИ ОТ КРАСНОГО ЛУЧА" if OS.has_feature("mobile") else "WASD / СТРЕЛКИ — УВОДИ КУРСОР ОТ КРАСНОГО ЛУЧА"
    _line(instruction, 196, 493, 17, ACCENT)


func _draw_ending() -> void:
    draw_rect(Rect2(0, 0, 960, 540), Color(0.04, 0.07, 0.11, 0.95))
    draw_rect(Rect2(110, 123, 740, 302), PANEL)
    draw_rect(Rect2(110, 123, 740, 4), ACCENT)
    var ending: Array = state.get("ending", [])
    for i in range(ending.size()):
        _line(str(ending[i]), 137, 173 + i * 47, 22 if i == 0 else 19, ACCENT if i == 0 else WHITE)
    _line("↻ — НАЧАТЬ ЗАНОВО" if OS.has_feature("mobile") else "R — НАЧАТЬ ЗАНОВО", 365, 392, 19, ACCENT)
