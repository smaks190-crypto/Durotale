extends Node2D
class_name CorridorGame
## Вертикальный срез: исследование -> выбор -> проверка -> один из финалов.

@onready var world: WardWorld = $World
@onready var player: WardPlayer = $Player
@onready var overlay: GameOverlay = $HUD/Overlay
@onready var touch_controls: MobileControls = $HUD/TouchControls

const INTERACT_DISTANCE: float = 28.0
const OBJECTS = {
    "note": Vector2(77, 205),
    "nika": Vector2(161, 188),
    "archive": Vector2(291, 191),
    "scanner": Vector2(351, 70),
    "door": Vector2(426, 69),
}

var phase: String = "explore"
var lines: Array[String] = []
var options: Array[String] = []
var dialogue_action: String = ""
var has_badge: bool = false
var nika_trust: bool = false
var talked_to_nika: bool = false
var read_log: bool = false
var door_unlocked: bool = false
var alert_triggered: bool = false
var alarm_time: float = 0.0
var alarm_health: int = 3
var alarm_cursor: Vector2 = Vector2(480, 270)
var alarm_cooldown: float = 0.0
var pulse_x: float = 330.0
var ending_text: Array[String] = []


func _ready() -> void:
    _refresh_overlay()
    _say([
        "03:17. КОРПУС №7.",
        "Снаружи шумит дождь. Твоя дверь почему-то открыта.",
        "Сегодня можно уйти. Но какой ценой?",
    ])


func _process(delta: float) -> void:
    player.can_move = phase == "explore"
    _handle_mobile_actions()
    if phase == "alarm":
        _update_alarm(delta)
    touch_controls.update_phase(phase, options.size())
    _refresh_overlay()


func _refresh_overlay() -> void:
    overlay.set_state({
        "phase": phase,
        "lines": lines,
        "options": options,
        "hint": _get_interaction_hint(),
        "badge": has_badge,
        "trust": nika_trust,
        "time": alarm_time,
        "health": alarm_health,
        "cursor": alarm_cursor,
        "pulse_x": pulse_x,
        "ending": ending_text,
    })


func _handle_mobile_actions() -> void:
    # TouchScreenButton supports independent simultaneous touch pointers.
    if Input.is_action_just_pressed("mobile_action"):
        if phase == "explore":
            _interact()
        elif phase == "dialogue" and options.is_empty():
            _close_dialogue()
        elif phase == "ending":
            get_tree().reload_current_scene()
    if phase == "dialogue" and options.size() == 2:
        if Input.is_action_just_pressed("mobile_choice1"):
            _choose(0)
        elif Input.is_action_just_pressed("mobile_choice2"):
            _choose(1)
    if phase == "ending" and Input.is_action_just_pressed("mobile_restart"):
        get_tree().reload_current_scene()


func _unhandled_key_input(event: InputEvent) -> void:
    if not event is InputEventKey or not event.pressed or event.echo:
        return
    var key: Key = event.physical_keycode
    if phase == "explore":
        if key == KEY_E or key == KEY_ENTER or key == KEY_KP_ENTER:
            _interact()
    elif phase == "dialogue":
        if options.is_empty() and (key == KEY_E or key == KEY_ENTER or key == KEY_KP_ENTER or key == KEY_SPACE):
            _close_dialogue()
        elif options.size() == 2:
            if key == KEY_1 or key == KEY_KP_1:
                _choose(0)
            elif key == KEY_2 or key == KEY_KP_2:
                _choose(1)
    elif phase == "ending":
        if key == KEY_R:
            get_tree().reload_current_scene()


func _get_nearby_object() -> String:
    var closest: String = ""
    var best: float = INTERACT_DISTANCE
    for object_id in OBJECTS.keys():
        var distance: float = player.position.distance_to(OBJECTS[object_id])
        if distance < best:
            best = distance
            closest = object_id
    return closest


func _get_interaction_hint() -> String:
    if phase != "explore":
        return ""
    match _get_nearby_object():
        "note": return "E — Прочитать записку"
        "nika": return "E — Поговорить с Никой"
        "archive": return "E — Осмотреть стойку"
        "scanner": return "E — Пройти проверку"
        "door": return "E — Открыть выход"
    if OS.has_feature("mobile"):
        return "КРЕСТОВИНА — ДВИЖЕНИЕ    ● — ДЕЙСТВИЕ"
    return "WASD / СТРЕЛКИ — ДВИЖЕНИЕ"


func _interact() -> void:
    match _get_nearby_object():
        "note":
            _say([
                "На смятом листе: «Корпус закрывают в 04:00».",
                "Ни подписи, ни объяснений. Только время.",
            ])
        "nika":
            if talked_to_nika:
                _say(["Ника: «Я уже сказала всё, что знаю».", "«Дальше решение за тобой»."])
            else:
                _say([
                    "Ника: «Ты не должен был проснуться так рано».",
                    "«Охранная система не различает помощь и побег».",
                    "Как ответишь?",
                ], ["1 — Сказать правду и попросить помочь", "2 — Обмануть: «Я иду на обследование»"], "nika")
        "archive":
            if not has_badge:
                has_badge = true
                world.badge_taken = true
                world.queue_redraw()
                _say([
                    "На стойке лежит старый служебный пропуск.",
                    "Ты берёшь его. На обороте — твоё имя, зачёркнутое.",
                    "ПРОПУСК ПОЛУЧЕН.",
                ])
            else:
                read_log = true
                _say([
                    "В журнале дежурств: «Пациент №17 не опасен».",
                    "«Задержан до выяснения обстоятельств».",
                    "Почему эту строчку кто-то пытался стереть?",
                ])
        "scanner":
            if door_unlocked:
                _say(["Индикатор зелёный. Выход открыт."])
            elif not has_badge:
                _say(["СКАНЕР: «Нет пропуска. Доступ запрещён»."])
            elif nika_trust:
                door_unlocked = true
                world.door_unlocked = true
                world.scanner_enabled = false
                world.queue_redraw()
                _say([
                    "СКАНЕР: «Пропуск подтверждён».",
                    "Ника незаметно отключила проверку выхода.",
                    "Никто не пострадал. Дверь открыта.",
                ])
            else:
                _say([
                    "СКАНЕР: «Пропуск недействителен».",
                    "«Запущена проверка движения. Избегайте красного луча».",
                ], ["1 — Попробовать обойти датчик", "2 — Отступить и подготовиться"], "scanner")
        "door":
            if door_unlocked:
                if nika_trust:
                    _finish([
                        "ТИХИЙ ВЫХОД",
                        "Дверь закрылась без звука. Ника осталась внутри.",
                        "За оградой пахнет мокрым асфальтом.",
                        "Ты свободен. Но почему твое имя было зачёркнуто?",
                    ])
                else:
                    _finish([
                        "ПО ТУ СТОРОНУ СИГНАЛИЗАЦИИ",
                        "Сирена умолкла. Ты оказался на холодной улице.",
                        "На стене мигает табличка: «КОРПУС №7 — ЗАКРЫТ».",
                        "Кого именно здесь держали — тебя или тайну?",
                    ])
            else:
                _say(["На тяжёлой двери горит красный индикатор.", "Сначала нужно отключить блокировку у сканера."])
        _:
            _say(["Старые лампы мерцают. В конце коридора тихо гудит щиток."])


func _say(new_lines: Array[String], new_options: Array[String] = [], action: String = "") -> void:
    lines = new_lines
    options = new_options
    dialogue_action = action
    phase = "dialogue"
    _refresh_overlay()


func _close_dialogue() -> void:
    lines.clear()
    options.clear()
    dialogue_action = ""
    phase = "explore"


func _choose(choice: int) -> void:
    match dialogue_action:
        "nika":
            talked_to_nika = true
            if choice == 0:
                nika_trust = true
                _say([
                    "Ника: «Хорошо. Только никого не трогай».",
                    "«Найди пропуск на стойке и иди к сканеру».",
                    "«Я задержу автоматическую проверку».",
                ])
            else:
                nika_trust = false
                _say([
                    "Ника молча отступает. Она тебе не поверила.",
                    "Теперь система безопасности работает по протоколу.",
                ])
        "scanner":
            if choice == 0:
                _start_alarm()
            else:
                _say(["Ты отступаешь от сканера.", "Датчик продолжает мигать красным."])


func _start_alarm() -> void:
    phase = "alarm"
    options.clear()
    lines.clear()
    alert_triggered = true
    alarm_time = 0.0
    alarm_health = 3
    alarm_cooldown = 0.0
    alarm_cursor = Vector2(480, 270)
    _refresh_overlay()


func _update_alarm(delta: float) -> void:
    alarm_time += delta
    alarm_cooldown = maxf(alarm_cooldown - delta, 0.0)
    pulse_x = 480.0 + sin(alarm_time * 2.65) * 169.0
    var move := Vector2.ZERO
    if Input.is_action_pressed("ui_left") or Input.is_physical_key_pressed(KEY_A):
        move.x -= 1.0
    if Input.is_action_pressed("ui_right") or Input.is_physical_key_pressed(KEY_D):
        move.x += 1.0
    if Input.is_action_pressed("ui_up") or Input.is_physical_key_pressed(KEY_W):
        move.y -= 1.0
    if Input.is_action_pressed("ui_down") or Input.is_physical_key_pressed(KEY_S):
        move.y += 1.0
    alarm_cursor += move.normalized() * 245.0 * delta
    alarm_cursor.x = clampf(alarm_cursor.x, 313.0, 647.0)
    alarm_cursor.y = clampf(alarm_cursor.y, 179.0, 362.0)
    if alarm_cooldown <= 0.0 and absf(alarm_cursor.x - pulse_x) < 11.0:
        alarm_health -= 1
        alarm_cooldown = 1.0
        if alarm_health <= 0:
            _finish([
                "ВОЗВРАЩЕНИЕ",
                "Сработала сигнализация. Коридор залило светом.",
                "Тебя отвели обратно. Но теперь ты знаешь путь.",
                "Это не конец истории.",
            ])
            return
    if alarm_time >= 9.0:
        door_unlocked = true
        world.door_unlocked = true
        world.scanner_enabled = false
        world.queue_redraw()
        _say([
            "Девять секунд. Система перешла в безопасный режим.",
            "На сканере загорелся зелёный свет.",
            "Выход открыт — пока не приехала охрана.",
        ])


func _finish(new_ending: Array[String]) -> void:
    phase = "ending"
    ending_text = new_ending
    _refresh_overlay()
