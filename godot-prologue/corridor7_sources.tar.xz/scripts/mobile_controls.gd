extends Node2D
class_name MobileControls
## Multitouch gamepad, rendered only on touch-capable devices.
## Buttons emit mapped Input actions, so story logic is shared with keyboard.

var direction_buttons: Array[TouchScreenButton] = []
var action_button: TouchScreenButton
var choice1_button: TouchScreenButton
var choice2_button: TouchScreenButton
var restart_button: TouchScreenButton


func _ready() -> void:
    for name in ["mobile_action", "mobile_choice1", "mobile_choice2", "mobile_restart"]:
        if not InputMap.has_action(name):
            InputMap.add_action(name)
    direction_buttons.append(_button("left", Vector2(53, 414), "ui_left"))
    direction_buttons.append(_button("right", Vector2(187, 414), "ui_right"))
    direction_buttons.append(_button("up", Vector2(120, 347), "ui_up"))
    direction_buttons.append(_button("down", Vector2(120, 481), "ui_down"))
    action_button = _button("action", Vector2(852, 431), "mobile_action")
    choice1_button = _button("one", Vector2(783, 450), "mobile_choice1")
    choice2_button = _button("two", Vector2(860, 450), "mobile_choice2")
    restart_button = _button("restart", Vector2(846, 431), "mobile_restart")
    update_phase("dialogue", 0)


func _button(asset: String, center: Vector2, action: String) -> TouchScreenButton:
    var button := TouchScreenButton.new()
    button.name = asset.capitalize() + "Button"
    button.action = action
    button.texture_normal = load("res://assets/touch/%s.svg" % asset) as Texture2D
    button.position = center - Vector2(34.0, 34.0)
    button.visibility_mode = TouchScreenButton.VISIBILITY_TOUCHSCREEN_ONLY
    add_child(button)
    return button


func update_phase(phase: String, option_count: int) -> void:
    var moving: bool = phase == "explore" or phase == "alarm"
    for button in direction_buttons:
        button.visible = moving
    action_button.visible = phase == "explore" or (phase == "dialogue" and option_count == 0)
    choice1_button.visible = phase == "dialogue" and option_count == 2
    choice2_button.visible = phase == "dialogue" and option_count == 2
    restart_button.visible = phase == "ending"
