extends CharacterBody2D
class_name WardPlayer
## Герой. Используем CharacterBody2D для настоящих столкновений со стенами.

const WALK_SPEED: float = 94.0
var can_move: bool = true
var walk_time: float = 0.0


func _ready() -> void:
    var shape := RectangleShape2D.new()
    shape.size = Vector2(9, 8)
    var hitbox := CollisionShape2D.new()
    hitbox.shape = shape
    hitbox.position.y = 1.0
    add_child(hitbox)
    queue_redraw()


func _physics_process(delta: float) -> void:
    var direction := Vector2.ZERO
    if can_move:
        direction.x = (1.0 if Input.is_physical_key_pressed(KEY_D) or Input.is_action_pressed("ui_right") else 0.0) - (1.0 if Input.is_physical_key_pressed(KEY_A) or Input.is_action_pressed("ui_left") else 0.0)
        direction.y = (1.0 if Input.is_physical_key_pressed(KEY_S) or Input.is_action_pressed("ui_down") else 0.0) - (1.0 if Input.is_physical_key_pressed(KEY_W) or Input.is_action_pressed("ui_up") else 0.0)
    velocity = direction.normalized() * WALK_SPEED
    move_and_slide()
    if direction.length_squared() > 0.0:
        walk_time += delta * 10.0
    queue_redraw()


func _draw() -> void:
    var foot_offset := 1.0 if velocity.length_squared() > 0.0 and sin(walk_time) > 0.0 else 0.0
    draw_ellipse_shadow()
    draw_rect(Rect2(-6, 0, 5, 7 + foot_offset), Color("303847"))
    draw_rect(Rect2(1, 0, 5, 7 - foot_offset), Color("303847"))
    draw_rect(Rect2(-6, -9, 12, 11), Color("6f8c9b"))
    draw_rect(Rect2(-5, -8, 10, 2), Color("e1dbc9"))
    draw_rect(Rect2(-5, -17, 10, 10), Color("e9c7ae"))
    draw_rect(Rect2(-6, -19, 12, 5), Color("283344"))
    draw_rect(Rect2(-4, -13, 2, 2), Color("273140"))
    draw_rect(Rect2(2, -13, 2, 2), Color("273140"))


func draw_ellipse_shadow() -> void:
    draw_rect(Rect2(-7, 7, 14, 2), Color(0.05, 0.08, 0.13, 0.40))
