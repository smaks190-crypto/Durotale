extends Node2D
class_name WardWorld
## Мир нарисован простыми пиксельными примитивами — без внешних ассетов.

var door_unlocked: bool = false
var badge_taken: bool = false
var scanner_enabled: bool = true

const FLOOR = Color("263244")
const TILE = Color("2b394c")
const WALL = Color("172335")
const WALL_LIT = Color("384b5c")


func _ready() -> void:
    # Стены создаются как физические StaticBody2D с CollisionShape2D.
    _wall(Rect2(0, 0, 480, 14))
    _wall(Rect2(0, 255, 480, 15))
    _wall(Rect2(0, 0, 14, 270))
    _wall(Rect2(466, 0, 14, 270))
    _wall(Rect2(14, 101, 195, 10))
    _wall(Rect2(257, 101, 209, 10))


func _wall(rect: Rect2) -> void:
    var wall_body := StaticBody2D.new()
    wall_body.position = rect.position + rect.size * 0.5
    var shape := RectangleShape2D.new()
    shape.size = rect.size
    var collider := CollisionShape2D.new()
    collider.shape = shape
    wall_body.add_child(collider)
    add_child(wall_body)


func _draw() -> void:
    draw_rect(Rect2(0, 0, 480, 270), FLOOR)
    for x in range(16, 464, 16):
        for y in range(16, 256, 16):
            if (int(x / 16) + int(y / 16)) % 2 == 0:
                draw_rect(Rect2(x, y, 16, 16), TILE)
    # Границы и два сегмента перегородки (с проходом посередине).
    for rect in [Rect2(0, 0, 480, 14), Rect2(0, 255, 480, 15), Rect2(0, 0, 14, 270), Rect2(466, 0, 14, 270), Rect2(14, 101, 195, 10), Rect2(257, 101, 209, 10)]:
        draw_rect(rect, WALL)
        draw_rect(Rect2(rect.position.x, rect.position.y, rect.size.x, 2), WALL_LIT)
    # Палата: кровать и шкаф с запиской.
    draw_rect(Rect2(29, 183, 60, 38), Color("41536a"))
    draw_rect(Rect2(33, 186, 52, 32), Color("afbdc7"))
    draw_rect(Rect2(35, 188, 18, 11), Color("e6ded1"))
    draw_rect(Rect2(33, 201, 52, 15), Color("678a9e"))
    draw_rect(Rect2(89, 180, 7, 48), Color("15202e"))
    draw_rect(Rect2(76, 205, 9, 5), Color("efdaa5"))
    # Стойка и архив.
    draw_rect(Rect2(269, 183, 52, 21), Color("171f2c"))
    draw_rect(Rect2(272, 178, 46, 9), Color("657b83"))
    draw_rect(Rect2(283, 178, 15, 7), Color("9aafbb"))
    draw_rect(Rect2(284, 184, 8, 4), Color("d6c37b") if not badge_taken else Color("445364"))
    # Медработница Ника.
    draw_rect(Rect2(154, 180, 15, 18), Color("d0d8d7"))
    draw_rect(Rect2(157, 172, 10, 11), Color("e4bca4"))
    draw_rect(Rect2(156, 171, 11, 4), Color("392d41"))
    draw_rect(Rect2(159, 184, 3, 6), Color("d06374"))
    draw_rect(Rect2(154, 198, 6, 7), Color("333a4b"))
    draw_rect(Rect2(164, 198, 6, 7), Color("333a4b"))
    # Камера контроля и лазерный сканер.
    draw_rect(Rect2(341, 54, 20, 23), Color("172532"))
    draw_rect(Rect2(345, 57, 12, 12), Color("344f60"))
    draw_circle(Vector2(351, 62), 3.0, Color("d6536e") if scanner_enabled else Color("69cda9"))
    # Выход из корпуса.
    draw_rect(Rect2(411, 24, 37, 59), Color("102231"))
    draw_rect(Rect2(417, 30, 25, 46), Color("526c79") if door_unlocked else Color("26364a"))
    draw_rect(Rect2(437, 54, 3, 5), Color("8bddb9") if door_unlocked else Color("f27b83"))
    # Слабый свет из окон вдоль северной стены.
    for x in [51, 137, 225]:
        draw_rect(Rect2(x, 15, 30, 7), Color("6e8797"))
        draw_rect(Rect2(x + 2, 22, 26, 13), Color("364c62"))
        draw_line(Vector2(x + 15, 22), Vector2(x + 15, 35), Color("718492"), 1)
    # Буквы мелкими табличками заменены цветными знаками.
    draw_rect(Rect2(221, 95, 25, 5), Color("94c5b3"))
